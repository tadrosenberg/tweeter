"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoStatusDao = void 0;
class DynamoStatusDao {
    getPageOfStories(token, userAlias, pageSize, lastItem) {
        throw new Error("Method not implemented.");
    }
    getPageOfFeeds(token, userAlias, pageSize, lastItem) {
        throw new Error("Method not implemented.");
    }
    postStatus(token, newStatus) {
        throw new Error("Method not implemented.");
    }
}
exports.DynamoStatusDao = DynamoStatusDao;
