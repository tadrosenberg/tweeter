"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoImageDao = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
const client_s3_2 = require("@aws-sdk/client-s3"); // For ACL settings
const BUCKET = "tads-tweeter";
const REGION = "us-east-1";
class DynamoImageDao {
    async uploadProfileImage(userAlias, imageStringBase64Encoded, imageFileExtension) {
        const fileName = `${userAlias}.${imageFileExtension}`;
        const decodedImageBuffer = Buffer.from(imageStringBase64Encoded, "base64");
        let contentType = "image/png";
        if (imageFileExtension.toLowerCase() === "jpg" ||
            imageFileExtension.toLowerCase() === "jpeg") {
            contentType = "image/jpeg";
        }
        const s3Params = {
            Bucket: BUCKET,
            Key: "images/" + fileName,
            Body: decodedImageBuffer,
            ContentType: contentType,
            ACL: client_s3_2.ObjectCannedACL.public_read,
        };
        const client = new client_s3_1.S3Client({ region: REGION });
        const command = new client_s3_1.PutObjectCommand(s3Params);
        try {
            await client.send(command);
            return `https://${BUCKET}.s3.${REGION}.amazonaws.com/images/${fileName}`;
        }
        catch (error) {
            throw new Error("s3 put image failed with: " + error);
        }
    }
    async getImageUrl(userAlias) {
        const fileName = `${userAlias}.png`;
        return `https://${BUCKET}.s3.${REGION}.amazonaws.com/images/${fileName}`;
    }
}
exports.DynamoImageDao = DynamoImageDao;
