"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoSessionDao = void 0;
class DynamoSessionDao {
    createAuthToken(userAlias, token, timestamp) {
        throw new Error("Method not implemented.");
    }
    getAuthToken(token) {
        throw new Error("Method not implemented.");
    }
    deleteAuthToken(sessionId) {
        throw new Error("Method not implemented.");
    }
}
exports.DynamoSessionDao = DynamoSessionDao;
