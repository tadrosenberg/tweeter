"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoSessionDao = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const TABLE_NAME = "auth";
const ddbClient = new client_dynamodb_1.DynamoDBClient({});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(ddbClient);
class DynamoSessionDao {
    async createAuthToken(userAlias, token, timestamp) {
        const params = {
            TableName: TABLE_NAME,
            Item: {
                userAlias,
                token,
                timestamp,
            },
        };
        const putResult = await docClient.send(new lib_dynamodb_1.PutCommand(params));
        return token;
    }
    async getAuthToken(token) {
        const getParams = {
            TableName: TABLE_NAME,
            Key: { token },
        };
        const result = await docClient.send(new lib_dynamodb_1.GetCommand(getParams));
        if (!result.Item) {
            console.warn("[getAuthToken] No token record found for token:", token);
            return false;
        }
        const record = result.Item;
        const storedTimestamp = record.timestamp;
        const now = Date.now();
        const tokenValidityWindow = 3 * 60 * 60 * 1000;
        if (now - storedTimestamp < tokenValidityWindow) {
            console.log("[getAuthToken] Token is valid.");
            return true;
        }
        else {
            console.warn("[getAuthToken] Token has expired.");
            // await this.deleteAuthToken(token);
            return false;
        }
    }
    async deleteAuthToken(token) {
        const params = {
            TableName: TABLE_NAME,
            Key: { token },
        };
        try {
            await docClient.send(new lib_dynamodb_1.DeleteCommand(params));
            console.log("[deleteAuthToken] Successfully deleted token:", token);
        }
        catch (error) {
            console.error("[deleteAuthToken] Error deleting auth token:", error);
            throw error;
        }
    }
}
exports.DynamoSessionDao = DynamoSessionDao;
