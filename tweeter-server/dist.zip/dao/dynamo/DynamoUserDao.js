"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoUserDao = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const ddbClient = new client_dynamodb_1.DynamoDBClient({});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(ddbClient);
const TABLE_NAME = "user";
class DynamoUserDao {
    async login(alias, password) {
        const getParams = {
            TableName: TABLE_NAME,
            Key: { alias },
        };
        const result = await docClient.send(new lib_dynamodb_1.GetCommand(getParams));
        if (!result.Item) {
            throw new Error("User not found");
        }
        const user = result.Item;
        const isMatch = await bcryptjs_1.default.compare(password, user.passwordHash);
        if (!isMatch) {
            throw new Error("Invalid password");
        }
        const { passwordHash, ...sanitizedUser } = user;
        return sanitizedUser;
    }
    async getUser(alias) {
        const getParams = {
            TableName: TABLE_NAME,
            Key: { alias },
        };
        const result = await docClient.send(new lib_dynamodb_1.GetCommand(getParams));
        if (!result.Item) {
            return null;
        }
        else {
            const user = result.Item;
            const { passwordHash, ...sanitizedUser } = user;
            return sanitizedUser;
        }
    }
    async createUser(user, password) {
        console.log("[createUser] Called with user:", user);
        const saltRounds = 10;
        console.log("[createUser] Generating hashed password...");
        const salt = await bcryptjs_1.default.genSalt(saltRounds);
        console.log("[createUser] Salt generated.");
        console.log("[createUser] Hashing password...");
        const hashedPassword = await bcryptjs_1.default.hash(password, salt);
        console.log("[createUser] Hashed password generated.");
        const userRecord = {
            ...user,
            passwordHash: hashedPassword,
        };
        console.log("[createUser] Final user record to insert:", userRecord);
        const params = {
            TableName: TABLE_NAME,
            Item: userRecord,
        };
        const putResult = await docClient.send(new lib_dynamodb_1.PutCommand(params));
        console.log("[createUser] PutCommand result:", putResult);
        const { passwordHash, ...sanitizedUser } = userRecord;
        console.log("[createUser] Returning sanitized user:", sanitizedUser);
        return sanitizedUser;
    }
}
exports.DynamoUserDao = DynamoUserDao;
