"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoDaoFactory = void 0;
const DynamoUserDao_1 = require("./DynamoUserDao");
const DynamoFollowDao_1 = require("./DynamoFollowDao");
const DynamoStatusDao_1 = require("./DynamoStatusDao");
const DynamoImageDao_1 = require("./DynamoImageDao");
const DynamoSessionDao_1 = require("./DynamoSessionDao");
class DynamoDaoFactory {
    createUserDao() {
        return new DynamoUserDao_1.DynamoUserDao();
    }
    createFollowDao() {
        return new DynamoFollowDao_1.DynamoFollowDao();
    }
    createStatusDao() {
        return new DynamoStatusDao_1.DynamoStatusDao();
    }
    createImageDao() {
        return new DynamoImageDao_1.DynamoImageDao();
    }
    createSessionDao() {
        return new DynamoSessionDao_1.DynamoSessionDao();
    }
}
exports.DynamoDaoFactory = DynamoDaoFactory;
