"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoFollowDao = void 0;
class DynamoFollowDao {
    getPageOfFollowers(userAlias, pageSize, lastItem) {
        throw new Error("Method not implemented.");
    }
    getPageOfFollowees(userAlias, pageSize, lastItem) {
        throw new Error("Method not implemented.");
    }
    follow(userToFollow) {
        throw new Error("Method not implemented.");
    }
    unfollow(userToUnfollow) {
        throw new Error("Method not implemented.");
    }
    getFollowerCount(userAlias) {
        throw new Error("Method not implemented.");
    }
    getFolloweeCount(userAlias) {
        throw new Error("Method not implemented.");
    }
    getFollowStatus(user, selectedUser) {
        throw new Error("Method not implemented.");
    }
}
exports.DynamoFollowDao = DynamoFollowDao;
