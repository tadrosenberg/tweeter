"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoFollowDao = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const ddbClient = new client_dynamodb_1.DynamoDBClient({});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(ddbClient);
const TABLE_NAME = "follow";
class DynamoFollowDao {
    async getPageOfFollowers(userAlias, pageSize, lastItem) {
        const params = {
            TableName: TABLE_NAME,
            IndexName: "followeeAlias-index",
            KeyConditionExpression: "followeeAlias = :alias",
            ExpressionAttributeValues: {
                ":alias": userAlias,
            },
            Limit: pageSize,
            ...(lastItem && {
                ExclusiveStartKey: {
                    followeeAlias: userAlias,
                    followerAlias: lastItem.alias,
                },
            }),
        };
        const result = await docClient.send(new lib_dynamodb_1.QueryCommand(params));
        const aliases = result.Items?.map((item) => item.followerAlias) || [];
        const hasMore = !!result.LastEvaluatedKey;
        return [aliases, hasMore];
    }
    async getPageOfFollowees(userAlias, pageSize, lastItem) {
        const lastAlias = lastItem ? lastItem.alias : null;
        const params = {
            TableName: TABLE_NAME,
            KeyConditionExpression: "followerAlias = :alias",
            ExpressionAttributeValues: {
                ":alias": userAlias,
            },
            Limit: pageSize,
            ...(lastAlias && {
                ExclusiveStartKey: {
                    followerAlias: userAlias,
                    followeeAlias: lastAlias,
                },
            }),
        };
        const result = await docClient.send(new lib_dynamodb_1.QueryCommand(params));
        const aliases = result.Items?.map((item) => item.followeeAlias) || [];
        const hasMore = !!result.LastEvaluatedKey;
        return [aliases, hasMore];
    }
    async follow(currentUser, userToFollow) {
        const params = {
            TableName: TABLE_NAME,
            Item: {
                followerAlias: currentUser,
                followeeAlias: userToFollow,
            },
        };
        try {
            await docClient.send(new lib_dynamodb_1.PutCommand(params));
            console.log(`[follow] ${currentUser} now follows ${userToFollow}`);
        }
        catch (error) {
            console.error(`[follow] Error adding follow relationship:`, error);
            throw error;
        }
    }
    async unfollow(currentUser, userToUnfollow) {
        const params = {
            TableName: TABLE_NAME,
            Key: {
                followerAlias: currentUser,
                followeeAlias: userToUnfollow,
            },
        };
        try {
            await docClient.send(new lib_dynamodb_1.DeleteCommand(params));
            console.log(`[unfollow] ${currentUser} unfollowed ${userToUnfollow}`);
        }
        catch (error) {
            console.error(`[unfollow] Error deleting follow relationship:`, error);
            throw error;
        }
    }
    async getFollowerCount(userAlias) {
        const params = {
            TableName: TABLE_NAME,
            IndexName: "followeeAlias-index",
            KeyConditionExpression: "followeeAlias = :userAlias",
            ExpressionAttributeValues: {
                ":userAlias": userAlias,
            },
            Select: "COUNT",
        };
        try {
            const result = await docClient.send(new lib_dynamodb_1.QueryCommand(params));
            console.log("[getFollowerCount] Query result:", result);
            return result.Count || 0;
        }
        catch (error) {
            console.error("[getFollowerCount] Error:", error);
            throw error;
        }
    }
    async getFolloweeCount(userAlias) {
        const params = {
            TableName: TABLE_NAME,
            KeyConditionExpression: "followerAlias = :userAlias",
            ExpressionAttributeValues: {
                ":userAlias": userAlias,
            },
            Select: "COUNT",
        };
        try {
            const result = await docClient.send(new lib_dynamodb_1.QueryCommand(params));
            console.log("[getFolloweeCount] Query result:", result);
            return result.Count || 0;
        }
        catch (error) {
            console.error("[getFolloweeCount] Error:", error);
            throw error;
        }
    }
    async getFollowStatus(user, selectedUser) {
        const params = {
            TableName: TABLE_NAME,
            Key: {
                followerAlias: user,
                followeeAlias: selectedUser,
            },
        };
        try {
            const result = await docClient.send(new lib_dynamodb_1.GetCommand(params));
            console.log("[getFollowStatus] Query result:", result);
            return !!result.Item;
        }
        catch (error) {
            console.error("[getFollowStatus] Error retrieving follow status:", error);
            throw error;
        }
    }
    async getFollowers(userAlias) {
        const aliases = [];
        let lastEvaluatedKey = undefined;
        do {
            const params = {
                TableName: TABLE_NAME,
                IndexName: "followeeAlias-index",
                KeyConditionExpression: "followeeAlias = :alias",
                ExpressionAttributeValues: {
                    ":alias": userAlias,
                },
                ExclusiveStartKey: lastEvaluatedKey,
            };
            try {
                const result = await docClient.send(new lib_dynamodb_1.QueryCommand(params));
                if (result.Items) {
                    for (const item of result.Items) {
                        if (item.followerAlias) {
                            aliases.push(item.followerAlias);
                        }
                    }
                }
                lastEvaluatedKey = result.LastEvaluatedKey;
            }
            catch (error) {
                console.error("[getFollowers] Error retrieving followers:", error);
                throw error;
            }
        } while (lastEvaluatedKey);
        return aliases;
    }
}
exports.DynamoFollowDao = DynamoFollowDao;
