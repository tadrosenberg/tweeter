"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const tweeter_shared_1 = require("tweeter-shared");
class UserService {
    userDao;
    sessionDao;
    imageDao;
    constructor(userDao, sessionDao, imageDao) {
        this.userDao = userDao;
        this.sessionDao = sessionDao;
        this.imageDao = imageDao;
    }
    login = async (alias, password) => {
        const user = await this.userDao.login(alias, password);
        const token = tweeter_shared_1.AuthToken.Generate().token;
        const loggedToken = await this.sessionDao.createAuthToken(user.alias, token, Date.now());
        return [user, loggedToken];
    };
    register = async (firstName, lastName, alias, password, userImageBytes, imageFileExtension) => {
        if ((await this.userDao.getUser(alias)) !== null) {
            throw new Error("[Bad Request] User already exists");
        }
        const imageUrl = await this.imageDao.uploadProfileImage(alias, userImageBytes, imageFileExtension);
        console.log("UserService.register params:", firstName, lastName, alias, password);
        const newUser = {
            firstName,
            lastName,
            alias,
            imageUrl: imageUrl,
        };
        const user = await this.userDao.createUser(newUser, password);
        console.log("made user, now trying auth token");
        const token = tweeter_shared_1.AuthToken.Generate().token;
        const loggedToken = await this.sessionDao.createAuthToken(user.alias, token, Date.now());
        console.log("made token");
        return [user, loggedToken];
    };
    getUser = async (token, alias) => {
        const isValid = await this.sessionDao.getAuthToken(token);
        if (!isValid) {
            console.warn("[Bad Request] Invalid token");
            return null;
        }
        return (await this.userDao.getUser(alias)) ?? null;
    };
    logout = async (token) => {
        await this.sessionDao.deleteAuthToken(token);
        console.log("[logout] Token deleted successfully");
    };
}
exports.UserService = UserService;
