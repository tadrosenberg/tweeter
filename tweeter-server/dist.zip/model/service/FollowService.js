"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FollowService = void 0;
const tweeter_shared_1 = require("tweeter-shared");
class FollowService {
    userDao;
    sessionDao;
    followDao;
    constructor(userDao, sessionDao, followDao) {
        this.userDao = userDao;
        this.sessionDao = sessionDao;
        this.followDao = followDao;
    }
    async loadMoreFollowers(token, userAlias, pageSize, lastItem) {
        if ((await this.sessionDao.getAuthToken(token)) === false) {
            throw new Error("[Bad Request] Invalid token");
        }
        const [items, hasMore] = await this.followDao.getPageOfFollowers(userAlias, pageSize, tweeter_shared_1.User.fromDto(lastItem));
        const userPromises = items.map((userAlias) => this.userDao.getUser(userAlias));
        const userDtosOrNull = await Promise.all(userPromises);
        const userDtos = userDtosOrNull.filter((dto) => dto !== null);
        return [userDtos, hasMore];
    }
    async loadMoreFollowees(token, userAlias, pageSize, lastItem) {
        if ((await this.sessionDao.getAuthToken(token)) === false) {
            throw new Error("[Bad Request] Invalid token");
        }
        const [items, hasMore] = await this.followDao.getPageOfFollowees(userAlias, pageSize, tweeter_shared_1.User.fromDto(lastItem));
        const userPromises = items.map((userAlias) => this.userDao.getUser(userAlias));
        const userDtosOrNull = await Promise.all(userPromises);
        const userDtos = userDtosOrNull.filter((dto) => dto !== null);
        return [userDtos, hasMore];
    }
    follow = async (token, userToFollow) => {
        const currentUser = await this.sessionDao.getUserfromToken(token);
        if (currentUser === null) {
            throw new Error("[Bad Request] User not found");
        }
        await this.followDao.follow(currentUser, userToFollow.alias);
        const followerCount = await this.getFollowerCount(token, userToFollow);
        const followeeCount = await this.getFolloweeCount(token, userToFollow);
        return [followerCount, followeeCount];
    };
    unfollow = async (token, userToUnfollow) => {
        const currentUser = await this.sessionDao.getUserfromToken(token);
        if (currentUser === null) {
            throw new Error("[Bad Request] User not found");
        }
        await this.followDao.unfollow(currentUser, userToUnfollow.alias);
        const followerCount = await this.getFollowerCount(token, userToUnfollow);
        const followeeCount = await this.getFolloweeCount(token, userToUnfollow);
        return [followerCount, followeeCount];
    };
    getFolloweeCount = async (token, user) => {
        if ((await this.sessionDao.getAuthToken(token)) === false) {
            throw new Error("[Bad Request] Invalid token");
        }
        return await this.followDao.getFolloweeCount(user.alias);
    };
    getFollowerCount = async (token, user) => {
        if ((await this.sessionDao.getAuthToken(token)) === false) {
            throw new Error("[Bad Request] Invalid token");
        }
        return this.followDao.getFollowerCount(user.alias);
    };
    getIsFollowerStatus = async (token, user, selectedUser) => {
        if ((await this.sessionDao.getAuthToken(token)) === false) {
            throw new Error("[Bad Request] Invalid token");
        }
        return await this.followDao.getFollowStatus(user.alias, selectedUser.alias);
    };
}
exports.FollowService = FollowService;
