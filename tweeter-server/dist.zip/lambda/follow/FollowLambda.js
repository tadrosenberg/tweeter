"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const FollowService_1 = require("../../model/service/FollowService");
const DynamoDaoFactory_1 = require("../../dao/dynamo/DynamoDaoFactory");
const handler = async (request) => {
    const daoFactory = new DynamoDaoFactory_1.DynamoDaoFactory();
    const userDao = daoFactory.createUserDao();
    const sessionDao = daoFactory.createSessionDao();
    const followDao = daoFactory.createFollowDao();
    const followService = new FollowService_1.FollowService(userDao, sessionDao, followDao);
    const [followerCount, followeeCount] = await followService.follow(request.token, request.user);
    return {
        success: true,
        message: null,
        followerCount: followerCount,
        followeeCount: followeeCount,
    };
};
exports.handler = handler;
