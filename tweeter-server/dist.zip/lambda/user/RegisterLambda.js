"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const UserService_1 = require("../../model/service/UserService");
const DynamoDaoFactory_1 = require("../../dao/dynamo/DynamoDaoFactory");
const handler = async (request) => {
    const daoFactory = new DynamoDaoFactory_1.DynamoDaoFactory();
    const userDao = daoFactory.createUserDao();
    const sessionDao = daoFactory.createSessionDao();
    const imageDao = daoFactory.createImageDao();
    const userService = new UserService_1.UserService(userDao, sessionDao, imageDao);
    console.log("Calling userService.register with:", request.alias, request.firstName, request.lastName);
    const [user, token] = await userService.register(request.firstName, request.lastName, request.alias, request.password, request.userImageBytes, request.imageFileExtension);
    console.log("Register successful. User:", user, "Token:", token);
    return {
        success: true,
        message: null,
        user: user,
        token: token,
    };
};
exports.handler = handler;
