"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const StatusService_1 = require("../../model/service/StatusService");
const DynamoDaoFactory_1 = require("../../dao/dynamo/DynamoDaoFactory");
const handler = async (request) => {
    const daoFactory = new DynamoDaoFactory_1.DynamoDaoFactory();
    const userDao = daoFactory.createUserDao();
    const sessionDao = daoFactory.createSessionDao();
    const followDao = daoFactory.createFollowDao();
    const statusDao = daoFactory.createStatusDao();
    const statusService = new StatusService_1.StatusService(userDao, sessionDao, followDao, statusDao);
    const response = await statusService.postStatus(request.token, request.status);
    return {
        success: true,
        message: null,
    };
};
exports.handler = handler;
