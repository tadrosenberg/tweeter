"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_sqs_1 = require("@aws-sdk/client-sqs");
const DynamoFollowDao_1 = require("../../dao/dynamo/DynamoFollowDao");
const sqsClient = new client_sqs_1.SQSClient({ region: "us-east-1" });
const updateFeedsQueueUrl = "https://sqs.us-east-1.amazonaws.com/293404919967/UpdateFeedsQueue";
const handler = async (event) => {
    const followDao = new DynamoFollowDao_1.DynamoFollowDao();
    for (const record of event.Records) {
        try {
            const message = JSON.parse(record.body);
            console.log("Received message:", message);
            const followers = await followDao.getFollowers(message.userAlias);
            console.log(`Found ${followers.length} followers for ${message.userAlias}`);
            const batchSize = 25;
            for (let i = 0; i < followers.length; i += batchSize) {
                const batch = followers.slice(i, i + batchSize);
                const updateMessage = {
                    followers: batch,
                    userAlias: message.userAlias,
                    timestamp: message.timestamp,
                    post: message.post,
                };
                const params = {
                    QueueUrl: updateFeedsQueueUrl,
                    MessageBody: JSON.stringify(updateMessage),
                };
                await sqsClient.send(new client_sqs_1.SendMessageCommand(params));
                console.log("Sent update message for batch:", batch);
            }
        }
        catch (error) {
            console.error("Error processing a record:", error);
            throw error;
        }
    }
};
exports.handler = handler;
