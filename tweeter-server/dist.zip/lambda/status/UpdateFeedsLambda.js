"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const DynamoStatusDao_1 = require("../../dao/dynamo/DynamoStatusDao");
const DynamoUserDao_1 = require("../../dao/dynamo/DynamoUserDao");
const handler = async (event) => {
    const statusDao = new DynamoStatusDao_1.DynamoStatusDao();
    const userDao = new DynamoUserDao_1.DynamoUserDao();
    for (const record of event.Records) {
        try {
            const message = JSON.parse(record.body);
            console.log("Processing update feed message:", message);
            const followers = message.followers;
            const user = await userDao.getUser(message.userAlias);
            if (!user) {
                throw new Error(`User not found for alias: ${message.userAlias}`);
            }
            const newStatus = {
                post: message.post,
                timestamp: message.timestamp,
                user: user,
            };
            await statusDao.batchInsertFeedItems(followers, newStatus);
            console.log("Feed updated for followers:", followers);
        }
        catch (error) {
            console.error("Error processing update feed message:", error);
            throw error;
        }
    }
};
exports.handler = handler;
